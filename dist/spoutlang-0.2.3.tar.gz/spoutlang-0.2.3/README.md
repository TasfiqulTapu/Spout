<h3 align="center">
  <image src="https://github.com/TasfiqulTapu/Spout/assets/66732331/6ba91903-73ca-4ebe-9cf9-2ea2b5479140" width="256" height="128" alt="Spout">
</h3>


Spout is an interpreted programming language aimed at demistifying bit manipulation. 
